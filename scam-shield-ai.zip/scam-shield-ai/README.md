# Scam shield AI

A Pen created on CodePen.

Original URL: [https://codepen.io/Yanet-Bedilu/pen/myEzeeO](https://codepen.io/Yanet-Bedilu/pen/myEzeeO).

